import React from "react";

function About() {
  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-auto">About</div>
    </div>
  );
}

export default About;
