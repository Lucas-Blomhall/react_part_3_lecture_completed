import React from "react";

function ProductPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-auto">
        <h1>ProductPage</h1>
      </div>
    </div>
  );
}

export default ProductPage;
